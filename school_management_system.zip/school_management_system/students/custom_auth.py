from django.contrib.auth.backends import ModelBackend
from staffs.models import Student
from django.contrib.auth.models import User

class CustomAuthBackend(ModelBackend):
    def authenticate(self, request, username=None, password=None):
        try:
            # Get the student with the provided username from the PostgreSQL database
            student = Student.objects.get(username=username)
            # Check if the password matches
            if student.password == password:
                return student  # Authentication successful
        except Student.DoesNotExist:
            pass
        return None  # Authentication failed



