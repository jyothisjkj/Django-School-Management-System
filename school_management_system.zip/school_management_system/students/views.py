from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login,logout
from django.http import HttpResponse
from staffs.models import Student,std_messages
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.core.mail import EmailMessage


from students.custom_auth import CustomAuthBackend


#Global Variables
std_class = None

# Create your views here.
def student_login(request):



    if request.method == "POST":
        # getting all students from DB
        all_students = Student.objects.all()
        all_users = {}
        for i in all_students:
            all_users[i.username]=i.password
        
        

        #retrieving u_name, password
        u_name = request.POST.get("username")
        password = request.POST.get("pass")

        
    

        
        """ user = CustomAuthBackend().authenticate(request,username=u_name,password=password)
        if user is not None:
            login(request,user,backend='django.contrib.auth.backends.ModelBackend')

            s_class = Student.objects.get(username =u_name)
            s_class = s_class.standard

            return redirect("std-home",u_name=u_name)
        
        else:
            return HttpResponse("username or pass is incorrect") """
        

        # checking user match
        if u_name in all_users:

             
            
            if all_users[u_name]==password:
                global std_class
                std_class = Student.objects.get(username=u_name).standard
                print("std_class=",std_class)

                return redirect("std-home",u_name=u_name)
            
            else:   
                return HttpResponse("username or password is incorrect")
        else:
            return HttpResponse("Username or password is incorrect")
        
    return render(request,"students/students_login.html")

   

# page after logged IN for student
def std_home(request,u_name):

    all_messages = std_messages.objects.filter(std_standard=std_class).order_by("-date")


    return render(request,"students/std_home.html",{"user":u_name,"all_messages":all_messages})


#FILE UPLOAD
def file_upload(request,message_id,user):
    print(message_id)
    print(user)
    return redirect("send-mail")
    # return render(request,"students/file_upload.html",{"message_id":message_id,"User":user})



#SEND MAIL 
def send_mails(request):

   

    if request.method =="POST":
       
        name = request.POST.get("your_name")
        t_mail = request.POST.get("techer_mail")
        subject = request.POST.get("subject")
        message = request.POST.get("message")
        file = request.FILES.get("file")

        

        # send_mail(
        #     subject, #subject of mail
        #     message, #message
        #     name, #from mail
        #     [t_mail],
        #     fail_silently = False, # To mail
        # )

        email=EmailMessage(
            subject=subject,
            body=message,
            from_email=name,
            to=[t_mail],

        )
        
        if file:
            # Attach the uploaded file to the email.
            email.attach(file.name, file.read(), file.content_type)

            print("file uploded successfullly")

        try:
            email.send()
            print("Mail sent successfully!")
        except Exception as e:
            print("Error sending mail:", str(e))

       
        
        
        







    return render(request,"students/send_mail.html")


# LOG OUT

def std_logout(request):
    
    return redirect("student-login")