from django.urls import path
from . import views


urlpatterns = [
    path("",views.student_login,name="student-login"),
    path("home_student/<u_name>/",views.std_home,name = "std-home"),
    path("logout",views.std_logout,name="std-logout"),
    path("file_upload/<message_id>/<user>/",views.file_upload,name ="file-upload"),
    path("send_mail",views.send_mails,name="send-mail"),

]
