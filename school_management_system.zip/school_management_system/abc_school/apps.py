from django.apps import AppConfig


class AbcSchoolConfig(AppConfig):
    name = 'abc_school'
