from django.urls import path 
from . import views

urlpatterns = [
    path("",views.staff_login, name="staff-login"),
    path("signup/",views.staff_signup,name="staff-signup"),
    path("home-page/",views.staff_loginpage, name="staff-loginpage"),
    path("logout/",views.logout_section,name="logout-section"),
    path("add_student/",views.add_student,name="add-student"),
    path("delete_student/<roll_number>",views.delete_student,name="delete-student"),
    path("update_student/<roll_number>",views.update_student,name="update-student"),
    path("message_students/",views.message_students,name="message-students"),
    path("student_details/<roll_number>/<name>",views.student_details,name="student-details"),
    path("s_private_message/<roll_number>",views.student_private_message,name = "s-private"),
    path("forgot_password/",views.forgot_password,name="forgot-password"),
    path("password_reset/confirm/<int:user_id>/<str:token>/",views.password_reset,name="password-reset"),
]
